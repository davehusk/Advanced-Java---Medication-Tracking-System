package medicationtracking;

// Patients are people.
public class Patient extends Person {
    public Patient(int id, String name, int age, String phoneNumber) {
        super(id, name, age, phoneNumber);
    }
}
